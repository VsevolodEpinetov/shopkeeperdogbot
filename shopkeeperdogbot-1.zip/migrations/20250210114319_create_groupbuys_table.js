exports.up = function (knex) {
  return knex.schema.createTable('groupbuys', (table) => {
    table.bigInteger('telegramGroupID').primary();
    table.integer('projectID').references('id').inTable('projects').onDelete('CASCADE'); // Safer relation
    table.decimal('margin', 10, 2);
    table.timestamp('endDate').defaultTo(knex.fn.now());
    table.decimal('minPricePerMember', 10, 2);
    table.decimal('pricePerMember', 10, 2);
    table.jsonb('participants').defaultTo(knex.raw("'[]'::jsonb")); // Proper JSON default
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('groupbuys');
};
