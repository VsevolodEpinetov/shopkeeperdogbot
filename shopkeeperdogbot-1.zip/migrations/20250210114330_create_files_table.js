exports.up = function (knex) {
  return knex.schema.createTable('files', (table) => {
    table.bigInteger('groupbuyID').references('telegramGroupID').inTable('groupbuys').onDelete('CASCADE');
    table.bigInteger('filesID').primary();
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('files');
};
