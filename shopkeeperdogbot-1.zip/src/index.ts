import { Telegraf, Scenes, session, Context } from 'telegraf';
import dotenv from 'dotenv';
import path from 'path';
import { getAllFilesFromFolder } from './modules/util';
import * as db from './modules/db/actions';

// Load environment variables
dotenv.config();

// Ensure TELEGRAM_TOKEN exists
if (!process.env.TELEGRAM_TOKEN) {
  throw new Error("❌ Missing TELEGRAM_TOKEN in .env file.");
}

// Initialize bot
const bot = new Telegraf(process.env.TELEGRAM_TOKEN);

// Store user info when they send a message
bot.on('message', async (ctx: Context, next) => {
  await db.upsertUser(ctx.from);
  return next();
});

// Load all Group Buy scenes dynamically
const groupbuyScenes: Scenes.BaseScene<Context>[] = getAllFilesFromFolder(
  path.join(__dirname, './modules/groupbuy/scenes')
).map(file => require(file).default);

const stage = new Scenes.Stage(groupbuyScenes);

bot.use(session());
bot.use(stage.middleware());

// Register group buy module
import groupbuy from './modules/groupbuy';
bot.use(groupbuy);

// Start bot
bot.launch();

// Graceful shutdown
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
