const dotenv = require('dotenv')
require('dotenv').config();
const { ApifyClient } = require('apify-client');

// Initialize the ApifyClient with API token
const apifyClient = new ApifyClient({
  token: process.env.APIFY_TOKEN,
});

const pageFunctionString = `
async function pageFunction(context) {
    const { jQuery: $, page, request, log } = context;

    if (!$) {
        log.error("jQuery is not injected!");
        return {};
    }

    const projectName = $('.project-name').first().text() || 'Unknown';
    log.info(\`Project Name: \${projectName}\`);

    const descriptionMeta = $('meta[name="description"]').attr('content') || '';
    log.info(\`Description Meta: \${descriptionMeta}\`);

    const creatorName = descriptionMeta.includes(' is raising funds') 
        ? descriptionMeta.split(' is raising funds')[0] 
        : 'Unknown';
    log.info(\`Creator Name: \${creatorName}\`);

    const rewardsBlock = $('.sticky-rewards').first();
    const rewardsElements = rewardsBlock.find('li');

    log.info(\`Found \${rewardsElements.length} rewards elements\`);

    const rewards = [];

    rewardsElements.each(function () {
        const rewardName = $(this).find('h3').first().text();
        const rewardPrice = $(this).find('p').first().text().match(/[0-9]+$/g);
        const reward = {
            name: rewardName,
            price: rewardPrice
        }
        rewards.push(reward);
    });

    log.info(\`Extracted Rewards: \${JSON.stringify(rewards)}\`);

    return {
        url: request.url,
        projectName,
        creatorName,
        rewards
    };
}

`.trim();

// Prepare Actor input
const defaultKickstarterActor = {
  "runMode": "PRODUCTION",
  "startUrls": [
    {
      "url": "" // <- YOU HAVE TO MANUALLY DECLARE THIS URL
    }
  ],
  "keepUrlFragments": false,
  "linkSelector": "",
  "globs": [],
  "pseudoUrls": [],
  "excludes": [
    {
      "glob": "/**/*.{png,jpg,jpeg,pdf,avif,webp,mp4,gif}"
    }
  ],
  "pageFunction": pageFunctionString,
  "injectJQuery": true,
  "proxyConfiguration": {
    "useApifyProxy": true,
    "apifyProxyGroups": ["RESIDENTIAL"]
  },
  "proxyRotation": "RECOMMENDED",
  "initialCookies": [],
  "useChrome": true,
  "headless": false,
  "ignoreSslErrors": false,
  "ignoreCorsAndCsp": false,
  "downloadMedia": false,
  "downloadCss": true,
  "maxRequestRetries": 3,
  "maxPagesPerCrawl": 0,
  "maxResultsPerCrawl": 0,
  "maxCrawlingDepth": 0,
  "maxConcurrency": 50,
  "pageLoadTimeoutSecs": 60,
  "pageFunctionTimeoutSecs": 60,
  "waitUntil": [
    "networkidle2"
  ],
  "preNavigationHooks": "",
  "postNavigationHooks": "",
  "breakpointLocation": "NONE",
  "closeCookieModals": false,
  "maxScrollHeightPixels": 5000,
  "debugLog": false,
  "browserLog": false,
  "customData": {}
};

module.exports = {
  apifyClient,
  defaultKickstarterActor
}