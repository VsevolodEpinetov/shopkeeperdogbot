const { TelegramData } = require("../settings");

const generateGroupBuyMessage = (project, participants) => {
  let message = '';
  message += `🔗 <b>Project:</b> <a href="${project.link}">${project.name}</a>\n`;
  message += `💰 <b>Total Cost:</b> ${project.price}€\n\n`;
  message += `📌 <b>Buy-in starts at:</b> ${project.buyInPrice}€\n`;
  message += `📆 <b>Campaign Ends:</b> ${project.endDate}\n\n`;

  message += `🧑‍🤝‍🧑 <b>Participants List:</b>\n`;

  let paid = 0;
  let notPaid = 0;

  participants.forEach((user, index) => {
    const name = user.username ? `@${user.username}` : `${user.first_name || ''} ${user.last_name || ''}`.trim();
    const balanceStatus = user.balance >= project.cost ? "💰 Tab covers" : "❌ Tab won't cover";
    let paidStatus = user.paid ? "💰 Paid" : "❌ Not Paid";

    if (!balanceStatus) {
      paidStatus = balanceStatus;
    }

    if (paidStatus.indexOf('❌') < 0) {
      notPaid++
    } else {
      paid++;
    }

    message += `${index + 1}. <b>${name}</b> - ${paidStatus}\n`;
  });

  message += `\n🏦 <b>Balance Summary:</b>\n`;
  message += `✅ <b>Paid:</b> ${paid} users\n`;
  message += `❌ <b>Not Paid:</b> ${notPaid} users\n\n`;

  message += `📩 <b>How to Join:</b>\n`;
  message += `Click the button below to participate! ⬇️\n\n`;


  return splitMessage(message);
};

const splitMessage = (message) => {
  if (message.length <= TelegramData.Limits.MessageCharacters) {
    return [message]; // No split needed
  }

  const messages = [];
  let currentMessage = "";

  const lines = message.split("\n");

  lines.forEach(line => {
    if ((currentMessage + "\n" + line).length > TelegramData.Limits.MessageCharacters) {
      messages.push(currentMessage);
      currentMessage = line;
    } else {
      currentMessage += (currentMessage ? "\n" : "") + line;
    }
  });

  if (currentMessage) {
    messages.push(currentMessage);
  }

  return messages;
};

module.exports = { generateGroupBuyMessage, splitMessage };
