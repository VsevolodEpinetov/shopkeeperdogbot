const { Composer } = require("telegraf");
const util = require('../../util');
const { TelegramData } = require("../../settings");

module.exports = Composer.command('new', async (ctx) => {
  if (ctx.message.from.id != TelegramData.ChatsIDs.Epinetov) return;
  
  if (!ctx.session.project) ctx.session.project = {};
  ctx.session.project = {
    creator: '',
    name: '',
    url: '',
    hosted: false,
    allPledges: JSON.parse([]),
    selectedPledgeName: '',
    latePledgePrice: 0.00,
    price: 0.00,
    files: JSON.parse([]),
    thumbnail: '',
    tags: JSON.parse([])
  }

  if (!ctx.session.groupbuy) ctx.session.groupbuy = {};
  ctx.session.groupbuy = {
    telegramGroupID: parseInt(ctx.message.chat.id),
    margin: 10,
    minPricePerMember: 0.00,
    pricePerMember: 0.00,
    participants: JSON.parse([])
  }

  ctx.scene.enter('NEW_GROUPBUY_0_LINK');
})