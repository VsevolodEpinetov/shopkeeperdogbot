const { Scenes, Markup } = require("telegraf");
const { defaultKickstarterActor, apifyClient } = require("../../api/apify-client");

const currentStageName = 'NEW_GROUPBUY_0_LINK'
const nextStageName = 'NEW_GROUPBUY_1_CONFIRM'

const scene = new Scenes.BaseScene(currentStageName);

scene.enter(async (ctx) => {
  await ctx.replyWithHTML(`Send a <b>link</b>`).then(nctx => {
    ctx.session.toEdit = nctx.message_id;
    ctx.session.chatID = nctx.chat.id;
  });
});

scene.on('text', async (ctx) => {
  const link = ctx.message.text;
  await ctx.deleteMessage(ctx.message.message_id);
  await ctx.reply(`Getting data, standby.`, {
    parse_mode: "HTML",
    ...Markup.inlineKeyboard([
      Markup.button.callback('❌ Cancel', 'cancel')
    ])
  });

  const input = { ...defaultKickstarterActor, startUrls: [{ url: link }] };
  const run = await apifyClient.actor("moJRLRc85AitArpNN").call(input);

  try {
    const { items } = await apifyClient.dataset(run.defaultDatasetId).listItems();

    if (items.length === 0) {
      return ctx.reply("❌ No data found for this link. Please try another.");
    }

    ctx.session.url = items[0].url;
    ctx.session.name = items[0].projectName;
    ctx.session.creator = items[0].creatorName;
    ctx.session.pledges = items[0].rewards;

    ctx.scene.enter(nextStageName);

  } catch (error) {
    // The error is an instance of ApifyApiError
    const { message, type, statusCode, clientMethod, path } = error;
    // Log error for easier debugging 
    console.log({ message, statusCode, clientMethod, type });

    // console.error("Apify API Error:", error);
    ctx.reply("❌ Failed to fetch Kickstarter data. Please try again.");
    ctx.scene.leave();
  }
});

scene.action('cancel', (ctx) => {
  ctx.replyWithHTML('Cancelling the operation.')
  ctx.scene.leave();
})


module.exports = scene;
