const { Scenes, Markup } = require("telegraf");
const knex = require('../../db/index'); // Import Knex instance
const { generateGroupBuyMessage } = require("../util");

const currentStageName = "NEW_GROUPBUY_1_CONFIRM";
const scene = new Scenes.BaseScene(currentStageName);

scene.enter(async (ctx) => {
  ctx.session.currency = ctx.session.currency || '€';
  ctx.session.selectedPledge = ctx.session.selectedPledge || ctx.session.pledges[0];
  ctx.session.finalPrice = ctx.session.pledges[0].price;

  await updateMessage(ctx);
});

// Function to update currency & pledge selection messages
async function updateMessage(ctx) {
  const { currency, selectedPledge, pledges, url, name, creator } = ctx.session;

  // Generate pledge selection buttons (mark selected one)
  let pledgeButtons = pledges.map((pledge, index) =>
    [Markup.button.callback(
      pledge.name === (selectedPledge?.name || "") ? `✅ ${pledge.name} - ${currency ? `${currency}` : ""}${pledge.price}` : `${pledge.name} - ${currency ? `${currency}` : ""}${pledge.price}`,
      `pledge_${index}`
    )]
  );

  // Message content
  const message = `
✅ <b>Kickstarter Project Found!</b>
🔗 <b>Link:</b> <a href="${url}">${name}</a>
👤 <b>Creator:</b> ${creator}

💰 <b>Selected currency:</b> ${currency ? `${currency}` : "⚠️ Not selected yet"}

🎁 <b>Select the correct pledge tier:</b>
${selectedPledge ? `${selectedPledge.name} - ${currency ? `${currency}` : ""}${selectedPledge.price}` : "⚠️ Not selected yet"}
    `;

  const buttons = [
    ...pledgeButtons,
    [Markup.button.callback('Confirm', 'confirm')]
  ]

  if (ctx.session.temp) {
    await ctx.telegram.editMessageText(
      ctx.session.temp.chatID,
      ctx.session.temp.messageID,
      null,
      message,
      {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard(buttons)
      });
  } else {
    const sentMessage = await ctx.replyWithHTML(message, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard(buttons)
    })

    ctx.session.temp = {};
    ctx.session.temp.chatID = sentMessage.chat.id;
    ctx.session.temp.messageID = sentMessage.message_id;
  }
}

// Handle currency selection
scene.action(/^currency_(.+)$/, async (ctx) => {
  const selectedCurrency = ctx.match[1];
  ctx.session.currency = selectedCurrency;

  await ctx.answerCbQuery();
  await updateMessage(ctx);
});

// Handle pledge selection
scene.action(/^pledge_(\d+)$/, async (ctx) => {
  const pledgeIndex = parseInt(ctx.match[1]);
  ctx.session.selectedPledge = ctx.session.pledges[pledgeIndex];
  ctx.session.finalPrice = ctx.session.pledges[pledgeIndex].price;

  await ctx.answerCbQuery();
  await updateMessage(ctx); // Refresh buttons to show ✅
});

scene.action("confirm", async (ctx) => {
  try {
    const username = ctx.callbackQuery.from.username || ctx.callbackQuery.from.first_name;

    const project = {
      creator: ctx.session.creator,
      name: ctx.session.name,
      url: ctx.session.url,
      hosted: true,
      allPledges: JSON.stringify(ctx.session.pledges),
      selectedPledge: JSON.stringify(ctx.session.selectedPledge),
      price: parseFloat(ctx.session.price) || 0,
      files: JSON.stringify([]),
      thumbnail: '',
      tags: JSON.stringify([]),
      latePledgePrice: 0
    }

    const projectInsertResponse = await knex('projects').insert(project).returning('id');
    const projectID = projectInsertResponse[0]['id'];

    const groupbuy = {
      telegramGroupID: parseInt(ctx.session.telegramGroupID),
      projectID: projectID,
      margin: parseFloat(ctx.session.margin) || 10,
      minPrice: parseFloat(ctx.session.minPrice) || 0,
      finalPrice: parseFloat(ctx.session.finalPrice) || 900
    };

    const [groupbuyID] = await knex('groupbuys').insert(groupbuy).returning(['telegramGroupID']);

    await knex('users').insert({
      telegramID: ctx.callbackQuery.from.id,
      telegramUsername: username,
      telegramFirstName: ctx.callbackQuery.from.first_name,
      lastSeenAt: new Date(),
    }).onConflict('telegramID').merge();

    const telegramGroupID = parseInt(groupbuyID.telegramGroupID) || 0;  // ✅ Extract number
    const telegramID = parseInt(ctx.from.id) || 0; 

    await knex('groupbuy_participants').insert({
      telegramGroupID: telegramGroupID,
      telegramID: telegramID,
      paid: false
    });

    const participants = await knex('groupbuy_participants')
      .join('users', 'groupbuy_participants.telegramID', '=', 'users.telegramID')
      .leftJoin('balances', 'users.telegramID', '=', 'balances.telegramID') // Get user balance
      .where('groupbuy_participants.telegramGroupID', groupbuyID.telegramGroupID)
      .select(
        'users.telegramID',
        'users.telegramUsername as username',
        'users.telegramFirstName as first_name',
        'users.telegramLastName as last_name',
        'balances.current as balance',
        'groupbuy_participants.paid'
      );

    const groupData = {
      ...project,
      ...groupbuy
    }

    const message = generateGroupBuyMessage(groupData, participants)

    ctx.reply(message, {
      parse_mode: "HTML",
      ...Markup.inlineKeyboard(
        Markup.button.callback('🔘 Add me')
      )
    });

    ctx.scene.leave();
  } catch (error) {
    console.error("Error confirming groupbuy:", error);
    ctx.reply("❌ Failed to create Groupbuy. Please try again.");
  }
});

module.exports = scene;
