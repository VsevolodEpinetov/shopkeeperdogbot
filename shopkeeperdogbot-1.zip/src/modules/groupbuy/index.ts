const fs = require('fs');
const path = require('path');
const { getAllFilesFromFolder } = require('../util');
const { Composer } = require('telegraf');

const actionsPath = path.join(__dirname, './actions');
const commandsPath = path.join(__dirname, './commands');

const actions = fs.existsSync(actionsPath) 
  ? getAllFilesFromFolder(actionsPath).map(file => require(file)) 
  : [];

const commands = fs.existsSync(commandsPath) 
  ? getAllFilesFromFolder(commandsPath).map(file => require(file)) 
  : [];

module.exports = Composer.compose([...actions, ...commands]);
