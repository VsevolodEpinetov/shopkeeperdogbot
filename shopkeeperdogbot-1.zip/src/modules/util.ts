const fs = require('fs');
const path = require('path');
const { TelegramData } = require('./settings.js');


function sleep(ms) {
  return new Promise(resolve => {
    setTimeout(resolve, ms)
  })
}

function splitMenu (menu, rowSize = 5) {
  const result = [];

  if (menu.length > rowSize) {
    for (let i = 0; i < menu.length; i += rowSize) {
      // Берем кусочек массива от i до i + chunkSize
      result.push(menu.slice(i, i + rowSize));
    }
  } else {
    result.push(menu);
  }

  return result;
}

function isSuperUser (userId) {
  if (userId == TelegramData.ChatsIDs.Epinetov || userId == TelegramData.ChatsIDs.Ann) {
    return true;
  } else {
    return false;
  }
}


function getAllFilesFromFolder (dir) {
  const files = fs.readdirSync(dir);
  let allFiles = [];

  files.forEach(file => {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      allFiles = allFiles.concat(getAllFilesFromFolder(fullPath));  // Рекурсивно проходим по подпапкам
    } else {
      allFiles.push(fullPath);  // Добавляем путь к файлу
    }
  });

  return allFiles;
}

function hideMenu (ctx) {
  try {
    ctx.editMessageReplyMarkup({
      reply_markup: {}
    });
  }
  catch (err) { }
}

function getRandomInt (min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function isAdmin (telegramUserID) {
  const isAnAdmin = telegramUserID == TelegramData.ChatsIDs.Epinetov;

  return isAnAdmin;
}


function getCommandParameter (ctx) {
  return option = ctx.message.text.split(/ +/)[1];
}

module.exports = {

  splitMenu,
  getAllFilesFromFolder,
  hideMenu,
  sleep,
  getRandomInt,
  isAdmin,
  getCommandParameter,
  isSuperUser,


}
