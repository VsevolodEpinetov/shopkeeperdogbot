const knex = require('./index'); // Import the DB instance

// 🔹 Insert a new user or update last seen time
const upsertUser = async (user) => {
  try {
    await knex('users')
      .insert({
        telegramID: user.id,
        telegramUsername: user.username || null,
        telegramFirstName: user.first_name || null,
        telegramLastName: user.last_name || null,
        addedAt: new Date(),
        lastSeenAt: new Date(),
      })
      .onConflict('telegramID')
      .merge({ lastSeenAt: new Date() });
  } catch (error) {
    console.error('DB Error (upsertUser):', error);
  }
};

// 🔹 Get user by Telegram ID
const getUser = async (telegramID) => {
  try {
    return await knex('users').where('telegramID', telegramID).first();
  } catch (error) {
    console.error('DB Error (getUser):', error);
    return null;
  }
};

// 🔹 Create a new project
const createProject = async ({ creator, title, url, hosted, price }) => {
  try {
    const [id] = await knex('projects')
      .insert({
        creator,
        title,
        url,
        hosted,
        price,
      })
      .returning('id');

    return id;
  } catch (error) {
    console.error('DB Error (createProject):', error);
    return null;
  }
};

// 🔹 Get all projects
const getAllProjects = async () => {
  try {
    return await knex('projects').select('*');
  } catch (error) {
    console.error('DB Error (getAllProjects):', error);
    return [];
  }
};

// 🔹 Create a new group buy
const createGroupBuy = async ({ projectID, telegramGroupID, margin, minPrice, finalPrice, latePledgePrice, participants, thumbnail }) => {
  try {
    await knex('groupbuys').insert({
      projectID,
      telegramGroupID,
      margin,
      minPrice,
      finalPrice,
      latePledgePrice,
      participants: JSON.stringify(participants),
      thumbnail,
    });
  } catch (error) {
    console.error('DB Error (createGroupBuy):', error);
  }
};

// 🔹 Get all group buys
const getAllGroupBuys = async () => {
  try {
    return await knex('groupbuys').select('*');
  } catch (error) {
    console.error('DB Error (getAllGroupBuys):', error);
    return [];
  }
};

// Export all functions
module.exports = {
  upsertUser,
  getUser,
  createProject,
  getAllProjects,
  createGroupBuy,
  getAllGroupBuys,
};
