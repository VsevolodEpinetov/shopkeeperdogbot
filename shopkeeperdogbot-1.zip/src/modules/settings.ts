const TelegramData = {
  ChatsIDs: {
    Epinetov: '91430770',
    Ann: '101922344'
  },
  Limits: {
    MessageCharacters: 1024
  }
}

module.exports = {
  TelegramData
}